import React, { useState } from 'react';
import { X, Heart, MapPin, Clock, Star } from 'lucide-react';

interface Proposal {
  id: number;
  title: string;
  image: string;
  description: string;
  details: string;
  location: string;
  time: string;
  highlight: string;
}

const proposals: Proposal[] = [
  {
    id: 1,
    title: "Cena Romántica",
    image: "https://images.pexels.com/photos/3201921/pexels-photo-3201921.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Una velada perfecta bajo las estrellas",
    details: "Te invito a una cena íntima en un restaurante con vista panorámica de la ciudad. Disfrutaremos de una cena de tres tiempos, vino seleccionado y la mejor compañía. La noche será perfecta para conversar y conocernos mejor.",
    location: "Restaurante Mirador del Valle",
    time: "8:00 PM",
    highlight: "Mesa reservada con vista a la ciudad"
  },
  {
    id: 2,
    title: "Picnic en el Parque",
    image: "https://images.pexels.com/photos/1024359/pexels-photo-1024359.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Un día perfecto al aire libre",
    details: "Preparé una canasta llena de tus comidas favoritas para disfrutar en un hermoso parque. Tendremos una manta suave, música relajante y toda la tarde para nosotros. Podemos caminar, jugar y simplemente disfrutar de la naturaleza.",
    location: "Parque Central - Zona del Lago",
    time: "2:00 PM",
    highlight: "Canasta gourmet preparada especialmente"
  },
  {
    id: 3,
    title: "Noche de Cine",
    image: "https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=800",
    description: "Películas y palomitas bajo las estrellas",
    details: "Una experiencia única en el cine al aire libre. Veremos una película clásica romántica bajo un cielo estrellado, con mantas cómodas, palomitas gourmet y bebidas especiales. Será una noche mágica llena de risas y momentos especiales.",
    location: "Cinema Park - Pantalla Gigante",
    time: "7:30 PM",
    highlight: "Asientos VIP con vista perfecta"
  }
];

function App() {
  const [selectedProposal, setSelectedProposal] = useState<Proposal | null>(null);

  const openModal = (proposal: Proposal) => {
    setSelectedProposal(proposal);
  };

  const closeModal = () => {
    setSelectedProposal(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="text-center py-12 px-4">
        <div className="flex items-center justify-center mb-4">
          <Heart className="text-rose-500 w-8 h-8 mr-2" />
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-rose-600 to-purple-600 bg-clip-text text-transparent">
            Propuestas Especiales
          </h1>
          <Heart className="text-rose-500 w-8 h-8 ml-2" />
        </div>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Elige la aventura perfecta para nosotros. Cada opción está diseñada para crear momentos inolvidables juntos.
        </p>
      </div>

      {/* Proposals Grid */}
      <div className="max-w-6xl mx-auto px-4 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {proposals.map((proposal) => (
            <div
              key={proposal.id}
              onClick={() => openModal(proposal)}
              className="group cursor-pointer transform transition-all duration-300 hover:scale-105"
            >
              <div className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300">
                <div className="relative overflow-hidden">
                  <img
                    src={proposal.image}
                    alt={proposal.title}
                    className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="absolute bottom-4 left-4 right-4 text-white opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-4 group-hover:translate-y-0">
                    <p className="text-sm font-medium">{proposal.description}</p>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold text-gray-800 mb-2 group-hover:text-rose-600 transition-colors duration-300">
                    {proposal.title}
                  </h3>
                  <p className="text-gray-600 mb-4">{proposal.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-rose-500">
                      <Star className="w-4 h-4 mr-1 fill-current" />
                      <span className="text-sm font-medium">Especial para ti</span>
                    </div>
                    <div className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                      Click para ver
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {selectedProposal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto animate-slideUp">
            {/* Modal Header */}
            <div className="relative">
              <img
                src={selectedProposal.image}
                alt={selectedProposal.title}
                className="w-full h-64 object-cover rounded-t-3xl"
              />
              <button
                onClick={closeModal}
                className="absolute top-4 right-4 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full p-2 transition-all duration-200 hover:scale-110"
              >
                <X className="w-6 h-6 text-gray-600" />
              </button>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                <h2 className="text-3xl font-bold text-white mb-2">{selectedProposal.title}</h2>
                <p className="text-white/90 text-lg">{selectedProposal.description}</p>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-8">
              <div className="mb-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-3">¿Qué haremos?</h3>
                <p className="text-gray-600 leading-relaxed text-lg">{selectedProposal.details}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-rose-500 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-800">Ubicación</h4>
                    <p className="text-gray-600">{selectedProposal.location}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Clock className="w-5 h-5 text-purple-500 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-800">Hora</h4>
                    <p className="text-gray-600">{selectedProposal.time}</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-rose-50 to-purple-50 rounded-2xl p-6 mb-6">
                <div className="flex items-center mb-2">
                  <Star className="w-5 h-5 text-amber-500 mr-2 fill-current" />
                  <h4 className="font-semibold text-gray-800">Algo especial</h4>
                </div>
                <p className="text-gray-700">{selectedProposal.highlight}</p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={closeModal}
                  className="flex-1 bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white font-semibold py-4 px-6 rounded-2xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
                >
                  <Heart className="w-5 h-5 inline mr-2" />
                  ¡Me encanta esta idea!
                </button>
                <button
                  onClick={closeModal}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-4 px-6 rounded-2xl transition-all duration-300"
                >
                  Ver otras opciones
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes slideUp {
          from { 
            opacity: 0;
            transform: translateY(20px) scale(0.95);
          }
          to { 
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
        
        .animate-slideUp {
          animation: slideUp 0.4s ease-out;
        }
      `}</style>
    </div>
  );
}

export default App;